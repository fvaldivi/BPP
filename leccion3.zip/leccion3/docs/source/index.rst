.. Documentacion clase3 documentation master file, created by
   sphinx-quickstart on Wed Jun 29 17:15:51 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Documentacion clase3's documentation!
================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

Introduccion
===============
Esta es la practica de la leccion 3

Leccion3
===============
.. automodule:: leccion3
   :members:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
